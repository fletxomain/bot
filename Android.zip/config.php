<?php
declare(strict_types=1);

function load_env(string $file): array {
    $out = [];
    if (!is_file($file)) return $out;
    foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$k, $v] = explode('=', $line, 2);
        $v = trim($v);
        if ((str_starts_with($v, '"') && str_ends_with($v, '"')) ||
            (str_starts_with($v, "'") && str_ends_with($v, "'"))) {
            $v = substr($v, 1, -1);
        }
        $out[trim($k)] = $v;
    }
    return $out;
}

$env = load_env(__DIR__ . '/.env');
$get = static fn(string $k, string $default=''): string => (string)($env[$k] ?? getenv($k) ?: $default);

return [
    'bot_token' => $get('BOT_TOKEN'),
    'gemini_key' => $get('GEMINI_API_KEY'),
    'gemini_model' => $get('GEMINI_MODEL', 'gemini-3.6-flash'),
    'owner_id' => $get('OWNER_ID'),
    'required_channel' => $get('REQUIRED_CHANNEL', '@FLETXO_OWNER'),
    'join_url' => $get('JOIN_URL', 'https://t.me/FLETXO_OWNER'),
    'public_base_url' => rtrim($get('PUBLIC_BASE_URL'), '/'),
    'webhook_secret' => $get('WEBHOOK_SECRET'),
    'max_prompt_chars' => max(1000, (int)$get('MAX_PROMPT_CHARS', '12000')),
];

