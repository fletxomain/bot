<?php
declare(strict_types=1);
$c=require dirname(__DIR__).'/config.php';
header('Content-Type: text/plain; charset=utf-8');

echo "FVM AI BOT HEALTH\n";
echo "PHP: ".PHP_VERSION."\n";
echo "cURL: ".(function_exists('curl_init')?'YES':'NO')."\n";
echo "BOT TOKEN: ".($c['bot_token']!==''?'CONFIGURED':'MISSING')."\n";
echo "GEMINI KEY: ".($c['gemini_key']!==''?'CONFIGURED':'MISSING')."\n";
echo "PUBLIC BASE: ".($c['public_base_url']!==''?$c['public_base_url']:'MISSING')."\n";
echo "WEBHOOK: ".$c['public_base_url']."/webhook.php\n";
echo "PROJECT STORAGE: ".(is_dir(dirname(__DIR__).'/storage/projects')?'OK':'MISSING')."\n";
echo "PROJECT WRITABLE: ".(is_writable(dirname(__DIR__).'/storage/projects')?'YES':'NO')."\n";
