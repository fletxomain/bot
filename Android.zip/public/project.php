<?php
declare(strict_types=1);
$c=require dirname(__DIR__).'/config.php';
$id=(string)($_GET['id']??'');
if(!preg_match('/^[A-Za-z0-9-]+$/',$id)){http_response_code(400);exit('Invalid project.');}

$root=realpath(dirname(__DIR__).'/storage/projects');
$dir=realpath($root.'/'.$id);
if(!$root||!$dir||!str_starts_with($dir,$root.DIRECTORY_SEPARATOR)){http_response_code(404);exit('Project not found.');}

$file=$dir.'/index.html';
if(!is_file($file)){http_response_code(404);exit('index.html not found.');}

header('Content-Type: text/html; charset=utf-8');
readfile($file);
