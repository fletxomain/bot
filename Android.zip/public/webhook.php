<?php
declare(strict_types=1);

header('Content-Type: text/plain; charset=utf-8');

$c = require dirname(__DIR__) . '/config.php';
require dirname(__DIR__) . '/src/Telegram.php';
require dirname(__DIR__) . '/src/Gemini.php';
require dirname(__DIR__) . '/src/Publisher.php';
require dirname(__DIR__) . '/src/Bot.php';

try {
    if ($c['webhook_secret'] !== '') {
        $got = $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '';
        if (!hash_equals($c['webhook_secret'], $got)) {
            http_response_code(403);
            exit('Forbidden');
        }
    }

    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        echo "FVM WEBHOOK ONLINE\n";
        echo "Telegram must POST updates to this URL.\n";
        exit;
    }

    $update = json_decode($raw, true);
    if (!is_array($update)) {
        http_response_code(400);
        exit('Invalid Telegram JSON');
    }

    if ($c['bot_token'] === '') throw new RuntimeException('BOT_TOKEN is missing.');
    if ($c['public_base_url'] === '') throw new RuntimeException('PUBLIC_BASE_URL is missing.');

    $tg = new Telegram($c['bot_token']);
    $ai = new Gemini($c['gemini_key'], $c['gemini_model']);
    $publisher = new Publisher(dirname(__DIR__) . '/storage/projects', $c['public_base_url']);

    (new Bot($c, $tg, $ai, $publisher))->handle($update);

    echo 'OK';
} catch (Throwable $e) {
    http_response_code(500);
    echo 'FVM ERROR: ' . $e->getMessage();
}
