<?php
header('Content-Type: text/plain; charset=utf-8');
echo "FVM AI DEV BOT — ONLINE";
