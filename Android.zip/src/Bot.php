<?php
declare(strict_types=1);

final class Bot {
    public function __construct(private array $c, private Telegram $tg, private Gemini $ai, private Publisher $pub) {}

    public function handle(array $u): void {
        try {
            if(isset($u['callback_query'])) { $this->callback($u['callback_query']); return; }
            $m=$u['message']??null;
            if(!$m) return;
            $chat=(int)($m['chat']['id']??0);
            $uid=(int)($m['from']['id']??0);
            $text=trim((string)($m['text']??''));

            if($text==='/start') { $this->start($chat); return; }
            if($text==='/help') { $this->tg->send($chat,"🛠️ <b>FVM AI DEV BOT</b>\n\nSend a website/development prompt after membership verification."); return; }

            if(!$this->isMember($uid)) { $this->join($chat); return; }
            if($text==='') return;
            if(mb_strlen($text)>$this->c['max_prompt_chars']) {
                $this->tg->send($chat,'⚠️ Prompt is too long.');
                return;
            }

            $this->tg->send($chat,'⚙️ <b>Building...</b>\n\nGemini is generating the files. Please wait.');
            $answer=$this->ai->generate($text);
            $project=$this->pub->publish($answer);

            $files=htmlspecialchars(implode(', ',$project['files']),ENT_QUOTES,'UTF-8');
            $url=htmlspecialchars($project['url'],ENT_QUOTES,'UTF-8');
            $this->tg->send($chat,"🚀 <b>BUILD COMPLETE</b>\n\n🌐 <b>Live URL:</b> {$url}\n📦 <b>Files:</b> {$files}");
        } catch(Throwable $e) {
            $this->tg->send($chat ?? 0,'❌ <b>Error</b>\n\n'.htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8'));
        }
    }

    private function start(int $chat): void {
        $this->tg->send($chat,
            "⚡ <b>TEAM FVM AI DEV BOT</b>\n\n".
            "🔥 <b>FVM:</b> Build it. Fix it. Ship it.\n\n".
            "Join the channel, then verify your membership.",
            ['inline_keyboard'=>[
                [['text'=>'📢 JOIN CHANNEL','url'=>$this->c['join_url']]],
                [['text'=>'✅ CHECK MEMBERSHIP','callback_data'=>'check']]
            ]]
        );
    }

    private function join(int $chat): void {
        $this->tg->send($chat,
            "⛔ <b>Join required</b>\n\nYou must join the FVM channel first.",
            ['inline_keyboard'=>[
                [['text'=>'📢 JOIN CHANNEL','url'=>$this->c['join_url']]],
                [['text'=>'🔄 CHECK AGAIN','callback_data'=>'check']]
            ]]
        );
    }

    private function callback(array $q): void {
        $uid=(int)($q['from']['id']??0);
        $chat=(int)($q['message']['chat']['id']??0);
        $mid=(int)($q['message']['message_id']??0);
        $this->tg->callback((string)$q['id']);

        if(($q['data']??'')!=='check') return;
        if($this->isMember($uid)) {
            $this->tg->edit($chat,$mid,"✅ <b>Membership verified.</b>\n\nSend your website/development prompt now.");
        } else {
            $this->join($chat);
        }
    }

    private function isMember(int $uid): bool {
        if($uid<=0) return false;
        try {
            return in_array($this->tg->member($this->c['required_channel'],$uid),['creator','administrator','member'],true);
        } catch(Throwable) { return false; }
    }
}
