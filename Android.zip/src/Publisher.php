<?php
declare(strict_types=1);

final class Publisher {
    public function __construct(private string $root, private string $baseUrl) {}

    public function publish(string $response): array {
        $files=$this->extract($response);
        if(!isset($files['index.html'])) {
            throw new RuntimeException('AI did not return an index.html file. Ask it to create a complete website.');
        }

        $id=gmdate('Ymd-His').'-'.bin2hex(random_bytes(5));
        $dir=$this->root.'/'.$id;
        if(!mkdir($dir,0755,true) && !is_dir($dir)) throw new RuntimeException('Cannot create project directory.');

        foreach($files as $name=>$content) {
            file_put_contents($dir.'/'.$name,$content,LOCK_EX);
        }

        return [
            'id'=>$id,
            'url'=>$this->baseUrl.'/project.php?id='.rawurlencode($id),
            'files'=>array_keys($files),
        ];
    }

    private function extract(string $response): array {
        $files=[];
        preg_match_all('/FILE\s*:\s*([^\r\n]+)\s*```(?:html|css|javascript|js)?\s*\r?\n(.*?)```/is',$response,$m,PREG_SET_ORDER);
        foreach($m as $match) {
            $name=trim($match[1]);
            if(!preg_match('/^(index\.html|style\.css|script\.js)$/i',$name)) continue;
            $files[strtolower($name)]=trim($match[2]);
        }
        return $files;
    }
}
