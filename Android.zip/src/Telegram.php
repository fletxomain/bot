<?php
declare(strict_types=1);

final class Telegram {
    public function __construct(private string $token) {
        if ($token === '') throw new RuntimeException('BOT_TOKEN is missing in .env');
    }

    public function call(string $method, array $data=[]): array {
        $url = 'https://api.telegram.org/bot' . rawurlencode($this->token) . '/' . $method;
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);
        $body = curl_exec($ch);
        $error = curl_error($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false) throw new RuntimeException('Telegram cURL: ' . $error);
        $json = json_decode($body, true);
        if (!is_array($json)) throw new RuntimeException('Telegram returned invalid JSON.');
        if (($json['ok'] ?? false) !== true) {
            throw new RuntimeException('Telegram API: ' . ($json['description'] ?? ('HTTP ' . $status)));
        }
        return $json;
    }

    public function send(int|string $chatId, string $text, ?array $markup=null): void {
        $data=['chat_id'=>$chatId,'text'=>$text,'parse_mode'=>'HTML'];
        if ($markup) $data['reply_markup']=$markup;
        $this->call('sendMessage',$data);
    }

    public function edit(int|string $chatId,int $messageId,string $text,?array $markup=null): void {
        $data=['chat_id'=>$chatId,'message_id'=>$messageId,'text'=>$text,'parse_mode'=>'HTML'];
        if ($markup) $data['reply_markup']=$markup;
        $this->call('editMessageText',$data);
    }

    public function callback(string $id,string $text=''): void {
        $this->call('answerCallbackQuery',['callback_query_id'=>$id,'text'=>$text]);
    }

    public function member(string $channel,int|string $userId): string {
        $r=$this->call('getChatMember',['chat_id'=>$channel,'user_id'=>$userId]);
        return (string)($r['result']['status'] ?? '');
    }
}
