<?php
declare(strict_types=1);

final class Gemini {
    public function __construct(private string $key, private string $model) {}

    public function generate(string $prompt): string {
        if ($this->key === '') throw new RuntimeException('GEMINI_API_KEY is missing in .env');

        $system = <<<TXT
You are the FVM AI Developer.
Use a direct, frank developer tone. You may use mild developer slang or profanity when it naturally helps explain a bug, but remain constructive.
Your job is to create websites and software from user prompts.
For website generation, ALWAYS return files in this exact format:

FILE: index.html
```html
...complete file...
```

FILE: style.css
```css
...complete file...
```

FILE: script.js
```javascript
...complete file...
```

Only generate static website files: HTML, CSS and JavaScript.
Do not generate PHP, shell scripts, server configuration, credential files, or code intended to execute arbitrary server commands.
Make the website complete, responsive, polished and self-contained.
Never reveal API keys, passwords, bot tokens or private credentials.
TXT;

        $payload=[
            'system_instruction'=>['parts'=>[['text'=>$system]]],
            'contents'=>[['role'=>'user','parts'=>[['text'=>$prompt]]]],
            'generationConfig'=>[
                'temperature'=>0.7,
                'maxOutputTokens'=>20000,
            ],
        ];

        $url='https://generativelanguage.googleapis.com/v1beta/models/' .
             rawurlencode($this->model) . ':generateContent';

        $ch=curl_init($url);
        curl_setopt_array($ch,[
            CURLOPT_POST=>true,
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_CONNECTTIMEOUT=>15,
            CURLOPT_TIMEOUT=>150,
            CURLOPT_HTTPHEADER=>[
                'Content-Type: application/json',
                'x-goog-api-key: '.$this->key,
            ],
            CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
        ]);
        $body=curl_exec($ch);
        $error=curl_error($ch);
        $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
        curl_close($ch);

        if($body===false) throw new RuntimeException('Gemini cURL: '.$error);
        $json=json_decode($body,true);
        if(!is_array($json)) throw new RuntimeException('Gemini returned invalid JSON.');
        if($status>=400) throw new RuntimeException('Gemini HTTP '.$status.': '.($json['error']['message']??'Unknown API error'));

        $parts=$json['candidates'][0]['content']['parts']??[];
        $text='';
        foreach($parts as $part) $text.=(string)($part['text']??'');
        if($text==='') throw new RuntimeException('Gemini returned an empty response.');
        return $text;
    }
}
