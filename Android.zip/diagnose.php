<?php
declare(strict_types=1);
echo "FVM AI BOT DIAGNOSTIC\n";
echo "PHP ".PHP_VERSION."\n";
echo "cURL: ".(function_exists('curl_init')?'OK':'MISSING')."\n";
$hosts=['api.telegram.org','generativelanguage.googleapis.com'];
foreach($hosts as $h){
  $ip=gethostbyname($h);
  echo $h.": ".($ip!==$h ? $ip : "DNS FAILED")."\n";
}
