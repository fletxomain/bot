<?php
declare(strict_types=1);

header('Content-Type: text/plain; charset=utf-8');
$c = require __DIR__ . '/config.php';

if ($c['bot_token'] === '') exit("ERROR: BOT_TOKEN is missing in .env\n");
if ($c['public_base_url'] === '') exit("ERROR: PUBLIC_BASE_URL is missing in .env\n");

$base = rtrim($c['public_base_url'], '/');
$webhook = $base . '/webhook.php';

function telegram(string $token, string $method, array $data=[]): array {
    $url = 'https://api.telegram.org/bot' . $token . '/' . $method;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_POSTFIELDS => http_build_query($data),
    ]);
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if ($raw === false) throw new RuntimeException($err ?: 'cURL failed');
    $json = json_decode($raw, true);
    if (!is_array($json)) throw new RuntimeException('Telegram returned invalid JSON: ' . substr($raw, 0, 300));
    return $json;
}

try {
    $me = telegram($c['bot_token'], 'getMe');
    if (($me['ok'] ?? false) !== true) {
        exit("ERROR: Bot token rejected by Telegram.\n" . json_encode($me) . "\n");
    }

    $data = ['url' => $webhook];
    if ($c['webhook_secret'] !== '') $data['secret_token'] = $c['webhook_secret'];

    $set = telegram($c['bot_token'], 'setWebhook', $data);

    echo "BOT: " . ($me['result']['username'] ?? 'unknown') . "\n";
    echo "WEBHOOK: " . $webhook . "\n";
    echo "TELEGRAM: " . (($set['ok'] ?? false) ? 'SET' : 'FAILED') . "\n";
    echo json_encode($set, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n\n";

    $info = telegram($c['bot_token'], 'getWebhookInfo');
    echo "WEBHOOK INFO:\n";
    echo json_encode($info, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
} catch (Throwable $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
