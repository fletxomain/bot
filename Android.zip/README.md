# FVM AI DEV BOT — VPS Auto Publish Edition

This version is designed for a PHP VPS deployment.

## What it does
1. Telegram `/start` shows the FVM quote.
2. User joins the configured Telegram channel.
3. User presses CHECK MEMBERSHIP.
4. User sends a website/development prompt.
5. Gemini generates a structured website response.
6. The bot extracts HTML/CSS/JS files.
7. The files are published automatically into `storage/projects/<id>/`.
8. The bot returns the public project URL.

## Important
The bot itself cannot create a public internet server from nothing. You need to install this package once on a VPS/domain. After that, each generated static website can be published automatically.

For safety, this publisher only publishes static HTML/CSS/JS files. Do NOT execute AI-generated PHP directly inside the bot's own server process.

## Setup

Requirements:
- PHP 8.1+
- cURL extension
- HTTPS domain/subdomain
- Telegram bot token
- Gemini API key
- Bot must be administrator in the required Telegram channel for membership checks.

1. Copy `.env.example` to `.env`.
2. Fill `BOT_TOKEN`.
3. Fill `GEMINI_API_KEY` with a newly created/rotated key.
4. Set `PUBLIC_BASE_URL`, e.g. `https://bot.example.com`.
5. Set `OWNER_ID`.
6. Set `REQUIRED_CHANNEL` and `JOIN_URL`.
7. Point the web server document root to `public/`.
8. Run `php set_webhook.php` once.
9. Test `/start`.

## Exact URLs

If:
PUBLIC_BASE_URL=https://bot.example.com

Webhook:
https://bot.example.com/webhook.php

Generated site:
https://bot.example.com/project.php?id=PROJECT_ID

## Gemini

The project uses Google's REST `models.generateContent` endpoint and sends the API key through the `x-goog-api-key` header. See Google's current Gemini API documentation:
https://ai.google.dev/api
